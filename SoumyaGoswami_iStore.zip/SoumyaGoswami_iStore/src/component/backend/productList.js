export const productList = {
    Devices:
        [
            {
                key: 1,
                imgsrc: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpxDlEuinXomAXl9NiA3ktNH7NzdOrQ5AKv5YhvM_UJU-iprL5aKZsKpOvf3ToTQ-a4Bw&usqp=CAU',
                name: 'Iphone 13 Pro',
                price: '$800'
            },

            {
                key: 2,
                imgsrc: 'https://d2xamzlzrdbdbn.cloudfront.net/products/8130d28f-9adb-4cfb-ac3b-e02fc3eec7cb21170536.jpg',
                name: 'Iphone 13 Pro Max',
                price: '$900'
            },

            {
                key: 3,
                imgsrc: 'https://store.storeimages.cdn-apple.com/8756/as-images.apple.com/is/iphone-14-pro-finish-select-202209-6-7inch-deeppurple?wid=5120&hei=2880&fmt=p-jpg&qlt=80&.v=1663703841896',
                name: 'Iphone 14 Pro',
                price: '$1099'
            },

            {
                key: 4,
                imgsrc: 'https://m.media-amazon.com/images/I/71yzJoE7WlL._SX522_.jpg',
                name: 'Iphone 14 Pro Max',
                price: '$1299'
            },

        ]
}

