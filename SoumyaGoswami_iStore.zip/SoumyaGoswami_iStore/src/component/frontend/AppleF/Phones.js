import React from 'react';
import './Phones.css'

function Phones(props, product) {
    return (
        <div className=''>
            <div className='card'>
                <img className='phone-img' src={props.img} alt='' />
            </div>
            <span>{props.name}</span>
            <br></br>
            <span>{props.type}</span>
            <br></br>
            <span>{props.price}</span>
            <br></br>
            <button className='btn' onClick={()=> {props.addToCart(product)}}>Add Product</button>

        </div>
    );
}

export default Phones;