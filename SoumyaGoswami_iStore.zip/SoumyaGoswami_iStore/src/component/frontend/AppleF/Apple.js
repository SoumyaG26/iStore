import React from 'react';
import './Apple.css'
import Phones from './Phones';


function ApplePhones({appleItems, addToCart}) {
    return (  

        <div style = {{textAlign:'center'}}>
        <div className='product'>
            {appleItems.map((prodVar, index)=>{
                return(
                    <Phones
                    key={index}
                    img={prodVar.imgsrc}
                    name={prodVar.price}
                    type={prodVar.type}
                    addToCart={() => {addToCart(prodVar)}}
                    />
                );
            })}

        </div>
    
    </div>
    );
}

export default ApplePhones;