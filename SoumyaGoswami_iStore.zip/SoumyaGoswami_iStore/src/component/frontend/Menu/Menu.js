import React from 'react';
import { Route, Routes, NavLink} from 'react-router-dom';
import AboutUS from '../AboutUs/AboutUs'
import Cart from '../Cart/Cart'
import '../Menu/Menu.css'
import Apple from '../AppleF/Apple';

function Menu({appleItems, cart, addToCart, removeFromCart, handleCartClearance}) {
    return (
        <>
            <div className='welcome'>Welcome to Apple</div>
            <br></br>
            <div className='tool'>
                <ul>
                    <li>
                        <NavLink to='/aboutus' className="nav-link">About Us</NavLink>
                    </li>
                    <li>
                        <NavLink to='/apple' className="nav-link text-dark">Products List</NavLink>
                    </li>
                    <li><NavLink to='/cart' className="nav-link">Cart</NavLink>
                    </li>
                </ul>
            </div>
            <Routes>
                <Route exact path='/aboutus' element={<AboutUS />} />
                <Route exact path='/cart' element={<Cart 
                cart={cart}
                addToCart={addToCart}
                removeFromCart={removeFromCart}
                handleCartClearance={handleCartClearance}
                />} />
                <Route path='/apple' element={
                <Apple
                addToCart={addToCart}
                appleItems={appleItems} 
                />} />
            </Routes>
        </>
    );
}

export default Menu;

